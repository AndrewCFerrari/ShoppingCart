/*
 * Brian Gao(bcg833) and Andrew Ferrari(acf2282)
 * Assignment 3 Shopping Cart
 */

package Assignment3;

public class Grocery extends Item {
	//variables, constructor here
	
	private boolean isPerishable;
	
	public Grocery(String name, double price, int quantity, double weight, boolean isPerishable){
		super(name, price, quantity, weight);
		this.isPerishable = isPerishable;
	}

	public boolean isPerishable() {
		return isPerishable;
	}

	public void setPerishable(boolean isPerishable) {
		this.isPerishable = isPerishable;
	}
	
	public double getShippingCost(){
		double standardCost = super.getShippingCost();
		if(isPerishable()){
			return standardCost + standardCost*(0.2);
		}	
		return standardCost;
	}
	
	public double getTaxCost(){
		return 0;
	}
	
	
	//override calculatePrice() if necessary; Implement print methods as necessary	
	// Only re-implement stuff you cannot get from the superclass (Item)
	
}
