/*
 * Brian Gao(bcg833) and Andrew Ferrari(acf2282)
 * Assignment 3 Shopping Cart
 */

package Assignment3;

public class Item 
{
//Declare variables for this class. Think about its type: public, protected or private?
	protected String name;
	protected double price; 
	protected int quantity;
	protected double weight;
	public static double salesTaxRate = 0.1;
	
	
// You will need a constructor (Why?). Create it here.
	
	public Item(String name, double price, int quantity, double weight){
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.weight = weight;
	}
	
	public double calculatePrice() 
	{
		if(this.getQuantity() == 0){
			return 0;
		}
		double final_price = getShippingCost() + getTaxCost() + getPrice();
		return final_price;
	}
	
	public double getShippingCost(){
		double final_price = (20 * getWeight()) * getQuantity();
		return final_price;
	}
	 
	public double getTaxCost(){
		double final_price = getPrice()*salesTaxRate;
		return final_price;	
	}
	

	void printItemAttributes () 
	{
		//Print all applicable attributes of this class
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public double getWeight() {
		return weight;
	}


	public void setWeight(double weight) {
		this.weight = weight;
	}
}
