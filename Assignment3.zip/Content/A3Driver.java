/*
 * Brian Gao(bcg833) and Andrew Ferrari(acf2282)
 * Assignment 3 Shopping Cart
 */

package Assignment3;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class A3Driver {

	 public static void main(String[] args) 
	 {
		 //Open file; file name specified in args (command line)
		 if (args.length != 1) 
			{
				System.err.println ("Error: Incorrect number of command line arguments");
				System.exit(-1);
			}  
		 processLinesInFile (args[0]);	
	 }
	/******************************************************************************
	* Method Name: startTransactions                                              *
	* Purpose: Parses the input string and checks if the input is valid. If the   *
	*          input is valid startTransactions begins the transactions           *
	* Returns: None                                                               *
	******************************************************************************/  
	 public static void startTransactions(String input, ArrayList<Item> shoppingCart){
		//Parse input, take appropriate actions.
		String[] command = input.split("[ \\t]+");
		
		//validate input
		if(!validateInput(command)){
			System.out.println("Incorrect Input");
		}
		else{
			startOperation(command, shoppingCart);
		}
	 }
	 
	/******************************************************************************
	* Method Name: startOperation                                                 *
	* Purpose: Given the operation startOperation helps the program               *
	*          reach the right helper function                                    *
	* Returns: None                                                               *
	******************************************************************************/
	 public static void startOperation(String[] command, ArrayList<Item> shoppingCart){
		 String operationType = command[0].toLowerCase();
		 String insert = "insert";
		 String search = "search";
		 String delete = "delete";
		 String update = "update";
		 String print = "print";
		 if(operationType.equals(insert)){
			doInsert(command, shoppingCart);
		 }
		 else if(operationType.equals(search)){
			 doSearch(command, shoppingCart, true);
		 }
		 else if(operationType.equals(delete)){
			doDelete(command, shoppingCart);
		 }
		 else if(operationType.equals(update)){
			 doUpdate(command, shoppingCart);
		 }
		 else{
			 doPrint(command, shoppingCart);
		 }
	 }
	 
	/******************************************************************************
	* Method Name: getItem                                                        *
	* Purpose: Returns a new Item with the given parameters. Depending on whether *
	* 		   the item is clothing, electronics, or groceries, different relevant*
	*          variables will be instantiated.                                    *
	* Returns: An Item object instantiated depending on the given parameters      *
	******************************************************************************/
	 public static Item getItem(String[] command){
		 String clothing = "clothing";
		 String electronics = "electronics";
		 String groceries = "groceries";
		 String category = command[1];
		 String itemName = command[2];
		 double price = Double.parseDouble(command[3]);
		 int quantity = Integer.parseInt(command[4]);
		 double weight = Double.parseDouble(command[5]);
		 if(category.equals(clothing)){
			 Item currentItem = new Clothing(itemName, price, quantity, weight);
			 return currentItem;
		 }
		 else if(category.equals(electronics)){
			boolean fragility = getFragility(command[6]);
			String state = command[7];
			Item currentItem = new Electronics(itemName, price, quantity, weight, fragility, state);
			return currentItem;
		 }
		 else{
			 boolean perishability = getPerishability(command[6]);
			 Item currentItem = new Grocery(itemName, price, quantity, weight, perishability);
			 return currentItem;
		 }
	 }
	 
	/******************************************************************************
	* Method Name: getFragility                                                   *
	* Purpose: Returns true if the item is fragile and false otherwise            *
	* Returns: true if the item is fragile and false otherwise                    *
	******************************************************************************/
	 public static boolean getFragility(String isFragile){
		 if(isFragile.equals("F")){
			 return true;
		 }
		 return false;
	 }
	 
	/******************************************************************************
	* Method Name: getPerishability                                               *
	* Purpose: Returns true if the item given is perishable and false otherwise   *
	* Returns: true if the item given is perishable and false otherwise           *
	******************************************************************************/	 
	 public static boolean getPerishability(String isPerishable){
		 if(isPerishable.equals("P")){
			 return true;
		 }
		 return false;
	 }
	 
	/******************************************************************************
	* Method Name: doInsert                                                       *
	* Purpose: Inserts the given item into the arrayllist in non-case sensitive   *
	*          ascending order                                                    *
	* Returns: None                                                               *
	******************************************************************************/
	 public static void doInsert(String[] command, ArrayList<Item> shoppingCart){
		 if(shoppingCart.size() == 0){
			Item currentItem = getItem(command);
			shoppingCart.add(currentItem);
		 }
		 else{
			 Item currentItem = getItem(command);
			 String itemName = currentItem.getName().toLowerCase();
			 int i;
			 for(i = 0; i < shoppingCart.size(); i++){
				 if(itemName.compareTo(shoppingCart.get(i).getName().toLowerCase()) < 0){
					 shoppingCart.add(i, currentItem);
					 return;
				 }
			 }
			 shoppingCart.add(i, currentItem);
		 } 
	 }
	 
	 /******************************************************************************
		* Method Name: doPrint                                                        *
		* Purpose: Prints out all the important attributes of each item in the        *
		* 		   shopping cart                                                      *
		* Returns: None                                                               *
		******************************************************************************/
	 public static int doSearch(String[] command, ArrayList<Item> shoppingCart, boolean doPrint){
		 int quantity = 0;
		 int count = 0;
		 String itemName = command[1];
		 for(Item currentItem: shoppingCart){
			 if(currentItem.getName().equals(itemName)){
				 quantity += currentItem.getQuantity();
				 count++;
			 }
		 }
		 if(doPrint){
			 System.out.println(quantity + " " + itemName + "(s)" +  " found"); 
		 }
		 return count;
	 }
	 
	/******************************************************************************
	* Method Name: doDelete                                                       *
	* Purpose: deletes all the instances of the items with the given name from    *
	*          the shopping cart arraylist                                        *
	* Returns: None                                                               *
	******************************************************************************/
	 public static void doDelete(String[] command, ArrayList<Item> shoppingCart){
		 if(shoppingCart.size() == 0){
			 System.out.println("Empty Cart");
			 return;
		 }
		 int numberIterations = doSearch(command, shoppingCart, false);
		 int quantity = 0;
		 String itemName = command[1];
		 while(numberIterations > 0){
			 int indexOfCurrentItem = getIndex(itemName, shoppingCart);
			 quantity += shoppingCart.get(indexOfCurrentItem).getQuantity();
			 shoppingCart.remove(indexOfCurrentItem);
			 numberIterations--;
		 }
		 System.out.println(quantity + " " + itemName + "(s)" +  " deleted"); 
	 }
	
	/******************************************************************************
	* Method Name: getIndex                                                       *
	* Purpose: Returns the index of the item with the given name from the shopping*
	*          cart arraylist                                                     *
	* Returns: the index of the item and -1 if the item is not in the arraylist   *
	******************************************************************************/
	 public static int getIndex(String itemName, ArrayList<Item> shoppingCart){
		for(int i = 0; i < shoppingCart.size(); i++){
			Item currentItem = shoppingCart.get(i);
			if(currentItem.getName().equals(itemName)){
				return i; 
			}
		}
		return -1;
	 }
	 
	/******************************************************************************
	* Method Name: doUpdate                                                       *
	* Purpose: changes the quantity of the first instance of the name of the item *
	* 		   given                                                              *
	* Returns: None                                                               *
	******************************************************************************/ 
	 public static void doUpdate(String[] command, ArrayList<Item> shoppingCart){
		 String itemName = command[1];
		 int newQuantity = Integer.parseInt(command[2]);
		 for(Item currentItem: shoppingCart){
			 if(currentItem.getName().equals(itemName)){
				 currentItem.setQuantity(newQuantity);
				 break;
			 }
		 }
		 System.out.println(itemName + " is now " + newQuantity);
		 
	 }
	 
	/******************************************************************************
	* Method Name: doPrint                                                        *
	* Purpose: Prints out all the important attributes of each item in the        *
	* 		   shopping cart                                                      *
	* Returns: None                                                               *
	******************************************************************************/	 
	 public static void doPrint(String[] command, ArrayList<Item> shoppingCart){
		 if(shoppingCart.size() == 0){
			 System.out.println("Empty");
		 }
		 else{
			 double totalCharge = 0;
			 for(Item currentItem: shoppingCart){
				 String itemName = currentItem.getName();
				 int quantity = currentItem.getQuantity();
				 double price = currentItem.calculatePrice();
				 totalCharge += price;
				 System.out.println(quantity + " " + itemName + "(s) costs: $" + price);
			 }
			 System.out.println("Total Price of Cart: $" + totalCharge);
		 }
	 }
	
	/******************************************************************************
	* Method Name: processLinesInFile                                             *
	* Purpose: Opens the file specified in String filename, reads each line in it *
	*          Invokes translate () on each line in the file, and prints out the  *
	*          translated piglatin string.                                        *
	* Returns: None                                                               *
	******************************************************************************/
	public static void processLinesInFile (String filename) 
	{ 
		try 
		{
			FileReader freader = new FileReader(filename);
			BufferedReader reader = new BufferedReader(freader);
			ArrayList<Item> shoppingCart = new ArrayList<Item>(); 
			
			for (String s = reader.readLine(); s != null; s = reader.readLine()) 
			{
				startTransactions(s, shoppingCart);
			}
		} 
		catch (FileNotFoundException e) 
		{
			System.err.println ("Error: File not found. Exiting...");
			e.printStackTrace();
			System.exit(-1);
		} catch (IOException e) 
		{
			System.err.println ("Error: IO exception. Exiting...");
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	/******************************************************************************
	* Method Name: validateInput                                                  *
	* Purpose: Checks if the input given is valid in the correct format           *                                                            *
	* Returns: returns true if the input is correct and false otherwise           *
	******************************************************************************/
	public static boolean validateInput(String[] command) {
		 String operationType = command[0].toLowerCase();
		 String insert = "insert";
		 String search = "search";
		 String delete = "delete";
		 String update = "update";
		 String print = "print";
		 
		 String clothing = "clothing";
		 String groceries = "groceries";
		 String electronics = "electronics";
		 
		 if(operationType.equals(insert)){
			if(command.length < 6 || command.length > 8){
				return false;
			}
			String category = command[1];
			if(category.equals(clothing)){
				if(command.length != 6){
					return false;
				}
				if(!isNumeric(command[3])){
					return false;
				}
				if(!isNumeric(command[4])){
					return false;
				}
				double variable = Double.parseDouble(command[4]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				if(!isNumeric(command[5])){
					return false;
				}
				variable = Double.parseDouble(command[5]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				return true;
			}
			else if(category.equals(groceries)){
				if(command.length != 7){
					return false;
				}
				if(!isNumeric(command[3])){
					return false;
				}
				if(!isNumeric(command[4])){
					return false;
				}
				double variable = Double.parseDouble(command[4]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				if(!isNumeric(command[5])){
					return false;
				}
				variable = Double.parseDouble(command[5]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				if(!(command[6].toLowerCase().equals("p") || command[6].toLowerCase().equals("np"))){
					return false;
				}
				return true;
			}
			else if(category.equals(electronics)){
				String allStates ="akalazarcacoctdeflgahiidiliniakskylamemdmamimnmsmomtnenvnhnjnmnyncndohokorpariscsdtntxutvtvawawvwiwy";
				if(command.length != 8){
					return false;
				}
				if(!isNumeric(command[3])){
					return false;
				}
				if(!isNumeric(command[4])){
					return false;
				}
				double variable = Double.parseDouble(command[4]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				if(!isNumeric(command[5])){
					return false;
				}
				variable = Double.parseDouble(command[5]);
				if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
				   return false;
				}
				if(variable < 0){
					return false;
				}
				if(!(command[6].toLowerCase().equals("f") || command[6].toLowerCase().equals("nf"))){
					return false;
				}
				if(command[7].length() != 2){
					return false;
				}
				if(isNumeric(command[7].substring(0, 1)) || isNumeric(command[7].substring(1, 2))){
					return false;
				}
				if(!(allStates.contains(command[7].toLowerCase()))){
					return false;
				}
				return true;
			}
			else{
				return false;
			}
		 }
		 else if(operationType.equals(search)){
			if(command.length != 2){
				return false;
			}
			return true;
		 }
		 else if(operationType.equals(delete)){
			if(command.length != 2){
				return false;
			}
			return true;
		 }
		 else if(operationType.equals(update)){
			 if(command.length != 3){
					return false;
			}
			if(!isNumeric(command[2])){
				return false;
			}
			double variable = Double.parseDouble(command[2]);
			if (!(variable == Math.floor(variable)) && !Double.isInfinite(variable)) {
			   return false;
			}
			if(variable < 0){
				return false;
			}
			return true; 
		 }
		 else if(operationType.equals(print)){
			if(command.length != 1){
				return false;
			}
			return true;
		 }
		 else{
			 return false;
		 }
	}
	
	/******************************************************************************
	* Method Name: isNumeric                                                      *
	* Purpose: Checks if the given string is a number                             *
	* Returns: True if the String is a number and false otherwise                 *
	******************************************************************************/
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
		  double number = Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
		  return false;  
	  }  
	  return true;  
	}
}
