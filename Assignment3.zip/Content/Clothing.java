/*
 * Brian Gao(bcg833) and Andrew Ferrari(acf2282)
 * Assignment 3 Shopping Cart
 */

package Assignment3;

public class Clothing extends Item 
{

	// variables, constructors as necessary
	
	public Clothing(String name, double price, int quantity, double weight){
		super(name, price, quantity, weight);
	}
	
}
