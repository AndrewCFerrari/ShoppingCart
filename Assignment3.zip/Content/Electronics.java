/*
 * Brian Gao(bcg833) and Andrew Ferrari(acf2282)
 * Assignment 3 Shopping Cart
 */

package Assignment3;

public class Electronics extends Item 
{

	// Variables, constructors etc. here.
	private String state;
	private boolean isFragile;
	
	public Electronics(String name, double price, int quantity, double weight, boolean isFragile, String state){
		super(name, price, quantity, weight);
		this.state = state;
		this.isFragile = isFragile;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean isFragile() {
		return isFragile;
	}

	public void setFragile(boolean isFragile) {
		this.isFragile = isFragile;
	}

	//Implement calculate price/print methods as necessary
	public double getShippingCost(){
		double standardCost = super.getShippingCost();
		if(isFragile()){
			return standardCost + standardCost*(0.2);
		}	
		return standardCost;
	}
	
	public double getTaxCost(){
		String texas = "TX";
		String newMexico = "NM";
		String virginia = "VA";
		String arizona = "AZ";
		String arkansas = "AK";
		
		if(getState().equals(texas) || getState().equals(newMexico) || getState().equals(virginia) ||
				getState().equals(arizona) || getState().equals(arkansas)){
			return 0;
		}
		else{
			return super.getTaxCost();
		}
	}

}
